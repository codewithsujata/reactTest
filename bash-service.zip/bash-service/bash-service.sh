#!/bin/bash

# Set the path to the error log file
ERROR_LOG="/var/log/apache2/es.log"
ERROR_RECORD="/var/www/html/bash-service/error_record.txt"
# BASH_SERVICE="/var/www/html/bash-service/bash-service.service"

# Set the Discord webhook URL
# DISCORD_WEBHOOK_URL="https://discord.com/api/webhooks/1074954622617264168/n-Kj6vAycioGV6mkwBnYoGxJRG8k98Qcnmz0NbXT0MyoPLffjufL-9qlEhwUOeV2wqFT"

NOTICE_WEBHOOK_URL="https://discordapp.com/api/webhooks/1101008413770645574/gMp58Z7Dd2B3-yQlLHS9oEREZGjdFxxP0Pn3ZhzarV91hVtGKm5LE99DbdzFlzR24DRC"

WARNING_WEBHOOK_URL="https://discordapp.com/api/webhooks/1101008175798427728/RzRnKK21It7vy4qWfBDRJX2L0-fdrfi7lRLPGniB0iEE7UFAT-3iw4KPzn-bXvx1tPN7"

FATAL_WEBHOOK_URL="https://discordapp.com/api/webhooks/1101035595767222353/jcYM70kPp80-YGMkLeWg1gJZtKkqzbs6WqUfiXGWlY-QcnsGVHx11B-g6htT8eSefmRI"


# Create the error record file if it doesn't exist
touch "$ERROR_RECORD"
# touch "$BASH_SERVICE"

# Read the last line number from the error record file
last_line=$(cat "$ERROR_RECORD")

# Read the entire error log file from the beginning
new_lines=$(tail -n +"$last_line" "$ERROR_LOG")

# Send each new error message to the Discord webhook usingg curl
while read error_message; do
  if [[ "$error_message" == *"notice"* ]] && ! grep -Fxq "$error_message" "$ERROR_RECORD"; then
    curl -H "Content-Type: application/json" -X POST -d "{\"content\":\"\`\`\`diff\n$error_message\`\`\`\"}" "$NOTICE_WEBHOOK_URL"
    echo "$error_message" >> "$ERROR_RECORD"

  elif [[ "$error_message" == *"warn"* ]] && ! grep -Fxq "$error_message" "$ERROR_RECORD"; then
    curl -H "Content-Type: application/json" -X POST -d "{\"content\":\"\`\`\`diff\n$error_message\`\`\`\"}" "$WARNING_WEBHOOK_URL"
    echo "$error_message" >> "$ERROR_RECORD"

  elif [[ "$error_message" == *"fatal"* ]] && ! grep -Fxq "$error_message" "$ERROR_RECORD"; then
      curl -H "Content-Type: application/json" -X POST -d "{\"content\":\"\`\`\`diff\n$error_message\`\`\`\"}" "$FATAL_WEBHOOK_URL"
      echo "$error_message" >> "$ERROR_RECORD"
      # elif ! grep -q "Logger.INFO" <<< "$error_message" && ! grep -Fxq "$error_message" "$ERROR_RECORD"; then
      #   curl -H "Content-Type: application/json" -X POST -d "{\"content\":\"$error_message\"}" "$DISCORD_WEBHOOK_URL"
      #   echo "$error_message" >> "$ERROR_RECORD"
  fi
done <<< "$new_lines"

# Update the last line number
last_line=$(($(wc -l < "$ERROR_LOG") + 1))

# Save the last line number to the error record file
echo "$last_line" > "$ERROR_RECORD"

# Use inotifywait to monitor the error log file for new events
while inotifywait -q -e modify "$ERROR_LOG"; do
# Read the new lines added since the last iteration
new_lines=$(tail -n +"$last_line" "$ERROR_LOG")

  # Send each new error message to the Discord webhook using curl
  while read error_message; do
    # Check if the error message has already been sent
    if [[ "$error_message" == *"notice"* ]] && ! grep -Fxq "$error_message" "$ERROR_RECORD"; then
      curl -H "Content-Type: application/json" -X POST -d "{\"content\":\"\`\`\`diff\n$error_message\`\`\`\"}" "$NOTICE_WEBHOOK_URL"
      echo "$error_message" >> "$ERROR_RECORD"

    elif [[ "$error_message" == *"warn"* ]] && ! grep -Fxq "$error_message" "$ERROR_RECORD"; then
      curl -H "Content-Type: application/json" -X POST -d "{\"content\":\"\`\`\`diff\n$error_message\`\`\`\"}" "$WARNING_WEBHOOK_URL"
      echo "$error_message" >> "$ERROR_RECORD"

    elif [[ "$error_message" == *"fatal"* ]] && ! grep -Fxq "$error_message" "$ERROR_RECORD"; then
    curl -H "Content-Type: application/json" -X POST -d "{\"content\":\"\`\`\`diff\n$error_message\`\`\`\"}" "$FATAL_WEBHOOK_URL"
      echo "$error_message" >> "$ERROR_RECORD"
    # elif ! grep -q "Logger.INFO" <<< "$error_message" && ! grep -Fxq "$error_message" "$ERROR_RECORD"; then
    #   curl -H "Content-Type: application/json" -X POST -d "{\"content\":\"$error_message\"}" "$DISCORD_WEBHOOK_URL"
    #   echo "$error_message" >> "$ERROR_RECORD"
    fi
  done <<< "$new_lines"

  # Update the last line number
  last_line=$(($(wc -l < "$ERROR_LOG") + 1))

  # Save the last line number to the error record file
  echo "$last_line" > "$ERROR_RECORD"
done
